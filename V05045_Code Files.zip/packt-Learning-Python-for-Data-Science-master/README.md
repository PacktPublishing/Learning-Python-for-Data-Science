# packt-Learning-Python-for-Data-Science
The script files for the course of Learning Python for Data Science created by Ilyas published in July 2018 by PacktPub.

https://www.packtpub.com/big-data-and-business-intelligence/learning-python-data-science-video

Note: Before using the data files either put them in the same folder with the script, or point to their location by specifying the path in `pandas.read_csv()`
